# Icons

Replace these placeholder files with your actual app icons:

## Required Sizes
- `icon-192.png` — 192x192 pixels (used for PWA install prompt)
- `icon-512.png` — 512x512 pixels (used for splash screens)

## Recommended Tool
Use [Favicon.io](https://favicon.io/) or [RealFaviconGenerator](https://realfavicongenerator.net/) to generate icons from your logo.

## Design Tips
- Use a transparent background (PNG)
- Keep the logo centered with padding
- Test on both light and dark backgrounds
- Include a simple "N" or your brand mark